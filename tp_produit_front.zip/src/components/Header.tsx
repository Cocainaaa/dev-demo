import React from 'react';

export const Header: React.FC = () => {
  return (
    <nav className="navbar navbar-dark bg-danger"> 
      <span className="navbar-brand mb-0 h1">Produit TP</span>
    </nav>
  );
};
