export interface Product {
    id: number;
    nomClient: string;
    nomProduit: string;
    prix: number;
  }

export interface NewProduct {
    nomClient: string;
    nomProduit: string;
    prix: number;
  }
  
  